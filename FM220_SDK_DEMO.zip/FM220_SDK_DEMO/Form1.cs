﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ACPLFM220SDKCS;
using System.IO;
using System.Drawing.Imaging;
using System.Data.SqlClient;

namespace FM220_SDK_DEMO
{
    public partial class Form1 : Form , FM220_Scanner_Interface
    {
        static string imnane = "";
        private FM220_SDK_Main sdk;
        private bool connected = false;
        private string telKey = "";
        private bool isfirstfingerformatch = false;
        private bool issecondfingerformatch = false;
        byte[] firstFingerTemplate = null;
        byte[] secondFingerTemplate = null;
        byte[] fingerTamplate;
        int matchScore;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           string key =  Microsoft.VisualBasic.Interaction.InputBox("If you are using TELECOM device and you have KEY given then please enter key or keep it blank for GENERAL device.","ENTER KEY(IN CASE OF TELECOM DEVICES)","");
           this.telKey = key.Trim();
           sdk = new FM220_SDK_Main(this);
            this.disableCapture();
            btn_disconn.Enabled = false;
            lbl_srno.Text = "";
            lbl_nfiq.Text = "";
            pic_finger.Image = null;
            lbl_stat.Text = "Click on `CONNECT` button to initialize FM220 scanner.";
            Random rr = new Random();

            textBox3.Text = "ACC" + rr.Next(1234, 99999);
        }

        private void btn_connect_Click(object sender, EventArgs e)
        {
            try
            {
                FM220_Init_Result result;
                if(this.telKey == null || this.telKey.Equals("") || string.IsNullOrEmpty(this.telKey)){
                    result = sdk.initFM220Scanner();
                }else{
                   result = sdk.initFM220Scanner(telKey);
                    
                }
                
                //FM220_Init_Result result = 
                if(result.getResult()){
                    lbl_stat.Text = "FM220 Sensor connected successfully.";
                    lbl_srno.Text = result.getSerialNo();

                    this.enableCapture();
                    btn_disconn.Enabled = true;
                    btn_connect.Enabled = false;
                    connected = true;
                }
                else{
                    lbl_stat.Text = result.getError();
                    this.disableCapture();
                    btn_disconn.Enabled = false;
                    btn_connect.Enabled = true;
                    connected = false;
                }
            }catch(Exception ex){
                MessageBox.Show(ex.Message);
            }
        }
        private void disableCapture()
        {
            btn_back.Enabled = false;
            btn_noprv.Enabled = false;
            btn_prv.Enabled = false;
            matchfingcap1.Enabled = false;
            matchfingcap2.Enabled = false;
            btnmatch.Enabled = false;
        }
        private void enableCapture()
        {
            btn_back.Enabled = true;
            btn_noprv.Enabled = true;
            btn_prv.Enabled = true;
            matchfingcap1.Enabled = true;
            matchfingcap2.Enabled = true;
            btnmatch.Enabled = true;
        }
        private void btn_disconn_Click(object sender, EventArgs e)
        {
            try
            {
                sdk.unInitFM220();
                this.disableCapture();
                connected = false;
                btn_connect.Enabled = true;
                btn_disconn.Enabled = false;
                lbl_srno.Text = "";
                lbl_nfiq.Text = "";
                pic_finger.Image = null;
                pic_finger.BackColor = Color.White;
                lbl_stat.Text = "Click on `CONNECT` button to initialize FM220 scanner.";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            lbl_stat.Text = "Scanning...";
            lbl_nfiq.Text = "";
            this.disableCapture();
            btn_connect.Enabled = false;
            btn_disconn.Enabled = false;
            pic_finger.Image = null;
            pic_finger.BackColor = Color.Blue;
            IntPtr refpntr = this.pic_finger.Handle;
            sdk.CaptureFM220(false,false, ref refpntr);
        }

        private void btn_noprv_Click(object sender, EventArgs e)
        {
            lbl_stat.Text = "Scanning...";
            lbl_nfiq.Text = "";
            this.disableCapture();
            btn_connect.Enabled = false;
            btn_disconn.Enabled = false;
            pic_finger.Image = null;
            pic_finger.BackColor = Color.Cyan ;
            IntPtr refpntr = this.pic_finger.Handle;
            sdk.CaptureFM220(true,false, ref refpntr);
        }

        private void btn_prv_Click(object sender, EventArgs e)
        {
            lbl_stat.Text = "Scanning...";
            lbl_nfiq.Text = "";
            this.disableCapture();
            btn_connect.Enabled = false;
            btn_disconn.Enabled = false;
            pic_finger.Image = null;
            IntPtr refpntr = this.pic_finger.Handle;
            sdk.CaptureFM220(true,true,ref refpntr);
        }

        public void ScanCompleteFM220(FM220_Capture_Result result)
        {
            //HANDLE CROSS THREAD OPERATIONS.......................
            if (result.getResult()){
                /**
                 * 
                 * You can get template after capture(scan) completed.
                 */
                if(isfirstfingerformatch){
                    //first finger for matching
                    firstFingerTemplate = result.getISO_Template();
                }else if(issecondfingerformatch){
                    //second finger for matching
                    secondFingerTemplate = result.getISO_Template();
                }else{
                    //only capture finger.
                   fingerTamplate = result.getISO_Template();
                }
                


                /*
                 * 
                 * You can get finger Image Data after capture(scan) completed.
                 */
                byte[] fingImage = result.getImageData();

                Image x = (Bitmap)((new ImageConverter()).ConvertFrom(fingImage));
                Random r = new Random();

                string path =textBox1.Text; // your code goes here

                if(!Directory.Exists(@"F:/"+path))
                    Directory.CreateDirectory(@"F:/" + path);

                //if (!exists)
                // System.IO.Directory.CreateDirectory(Server.MapPath(subPath));


                //F:\Project\Dot Net\Fingerprint web n Standalone\new\Code
                imnane = textBox1.Text + "_1.jpg";
                x.Save(@"F:/Project/Dot Net/Fingerprint web n Standalone/new/Code/TrainedImages/" + imnane);
                imnane = textBox1.Text + "_" + r.Next(1, 9) + ".jpg";

                x.Save(@"F:/Project/Dot Net/Fingerprint web n Standalone/new/Code/TrainedImages/" + imnane);
                x.Save(@"F:/Project/Dot Net/Fingerprint web n Standalone/new/Code/FPImage/" + imnane);
                x.Save(@"F:/" + textBox1.Text + "/ " + imnane);                
                x.Save(@"F:/FP/ " + imnane);


                //Image ss = Image.FromStream(new MemoryStream(fingImage));
                //pic_finger.Image = ss;

                //ss.Save(@"F:/img.jpg");
                //ss.Dispose();


                if (this.InvokeRequired)
                {
                    this.BeginInvoke((MethodInvoker)delegate
                    {
                        lbl_stat.Text = "Success";
                        lbl_srno.Text = result.getSerialNo();
                        lbl_nfiq.Text = result.getNFIQ().ToString();
                        this.enableCapture();
                        if (connected)
                        {
                            this.btn_connect.Enabled = false;
                            this.btn_disconn.Enabled = true;
                        }
                        else
                        {
                            this.btn_connect.Enabled = true;
                            this.btn_disconn.Enabled = false;
                        }
                    });
                }
                else
                {
                    lbl_stat.Text = "Success";
                    lbl_srno.Text = result.getSerialNo();
                    lbl_nfiq.Text = result.getNFIQ().ToString();
                    this.enableCapture();
                    if (connected)
                    {
                        this.btn_connect.Enabled = false;
                        this.btn_disconn.Enabled = true;
                    }
                    else
                    {
                        this.btn_connect.Enabled = true;
                        this.btn_disconn.Enabled = false;
                    }
                }
                
            }else{
                if (this.InvokeRequired)
                {
                    this.BeginInvoke((MethodInvoker)delegate
                    {
                        lbl_stat.Text = result.getError();
                        lbl_srno.Text = "";
                        lbl_nfiq.Text = "";
                        this.enableCapture();
                        if (connected)
                        {
                            this.btn_connect.Enabled = false;
                            this.btn_disconn.Enabled = true;
                        }
                        else
                        {
                            this.btn_connect.Enabled = true;
                            this.btn_disconn.Enabled = false;
                        }
                    });
                }
                else
                {
                    lbl_stat.Text = result.getError();
                    lbl_srno.Text = "";
                    lbl_nfiq.Text = "";
                    this.enableCapture();
                    if (connected)
                    {
                        this.btn_connect.Enabled = false;
                        this.btn_disconn.Enabled = true;
                    }
                    else
                    {
                        this.btn_connect.Enabled = true;
                        this.btn_disconn.Enabled = false;
                    }
                }
                
            }
        }

        public void ScannerProgressFM220(bool DisplayText, string statusMessage)
        {
           if (DisplayText ){
               if (this.InvokeRequired)
               {
                   this.BeginInvoke((MethodInvoker)delegate
                   {
                       lbl_stat.Text = statusMessage;
                   });
               }
               else
               {
                   lbl_stat.Text = statusMessage;
               }
               
           }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                sdk.unInitFM220();
            }catch(Exception ex){
            }
        }

        private void matchfingcap1_Click(object sender, EventArgs e)
        {
            lbl_stat.Text = "Scanning...";
            lbl_nfiq.Text = "";
            this.disableCapture();
            btn_connect.Enabled = false;
            btn_disconn.Enabled = false;
            pic_finger.Image = null;
            IntPtr refpntr = this.pic_finger.Handle;
            isfirstfingerformatch = true;
            issecondfingerformatch = false;
            sdk.CaptureFM220(true, true, ref refpntr);

            //System.Drawing.Image.FromHbitmap(refpntr);

            //using (Bitmap image = new Bitmap(256, 100, 256 * 4,PixelFormat.Format32bppRgb, refpntr))
            //{
            //    image.Save(@"F:/greyscale.png");
            //}


        }

        private void matchfingcap2_Click(object sender, EventArgs e)
        {
            lbl_stat.Text = "Scanning...";
            lbl_nfiq.Text = "";
            this.disableCapture();
            btn_connect.Enabled = false;
            btn_disconn.Enabled = false;
            pic_finger.Image = null;
            IntPtr refpntr = this.pic_finger.Handle;
            isfirstfingerformatch = false;
            issecondfingerformatch = true;
            sdk.CaptureFM220(true, true, ref refpntr);
        }

        private void btnmatch_Click(object sender, EventArgs e)
        {
            if(firstFingerTemplate == null){
                MessageBox.Show("Please capture first finger for match");
            }
            else if (secondFingerTemplate == null)
            {
                MessageBox.Show("Please capture second finger for match");
            }
            else
            {
                int[] score = new int[1];
                int[] matchingRes = sdk.matchFingerTamplates(ref firstFingerTemplate, ref secondFingerTemplate);
                if (matchingRes[0] == -1)
                {
                    MessageBox.Show("FINGERS DID NOT MATCH: MATCHING SCORE -" + matchingRes[1].ToString());
                }else{
                    MessageBox.Show("FINGERS MATCHED: MATCHING SCORE - " + matchingRes[1].ToString());
                }
               
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            byte[] arr = firstFingerTemplate;
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\Project\Dot Net\Fingerprint web n Standalone\FM220_SDK_DEMO\db\VoiceAtmDb.mdf;Integrated Security=True;Connect Timeout=30");
            con.Open();
            String query = "insert into Account values('"+textBox1.Text+"','','"+textBox3.Text+"','"+imnane+ "',@Content,'" + textBox4.Text + "','" + textBox2.Text + "')";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlParameter param = cmd.Parameters.Add("@Content", SqlDbType.VarBinary);
            param.Value = arr;
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Fingerprint captured successfully");
        }

        private void label8_Click(object sender, EventArgs e)
        {
            Home h = new Home();
            this.Hide();
            h.ShowDialog();
            this.Close();
        }
    }
}
