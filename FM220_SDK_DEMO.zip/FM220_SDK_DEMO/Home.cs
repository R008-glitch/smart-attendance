﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Speech.Recognition;
using System.Speech.Synthesis;
using System.Text;
using System.Windows.Forms;

namespace FM220_SDK_DEMO
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
            this.Enabled = false;
            this.Hide();

        }

        private void Home_Load(object sender, EventArgs e)
        {
            SpeechRecognitionEngine recEngine = new SpeechRecognitionEngine();
            SpeechSynthesizer synth = new SpeechSynthesizer();
            synth.SetOutputToDefaultAudioDevice();
            synth.Rate = -2;
            synth.Speak("Welcome to Finger Print APPLICATION");
        }

        private void label2_Click(object sender, EventArgs e)
        {

            Userhom f = new Userhom();
            this.Hide();
            f.ShowDialog();
            this.Close();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }
    }
}
