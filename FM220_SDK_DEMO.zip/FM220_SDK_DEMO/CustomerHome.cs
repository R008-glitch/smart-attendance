﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Speech.Recognition;
using System.Speech.Synthesis;
using System.Text;
using System.Windows.Forms;

namespace FM220_SDK_DEMO
{
    public partial class CustomerHome : Form
    {
        static string nn = "";
        static string an = "";
        SpeechRecognitionEngine recEngine = new SpeechRecognitionEngine();
        SpeechSynthesizer synth = new SpeechSynthesizer();
        public CustomerHome()
        {
            InitializeComponent();
        }
        public CustomerHome(String Aname,String Anum)
        {
            InitializeComponent();
            nn = Aname;
            an = Anum;
        }

        private void CustomerHome_Load(object sender, EventArgs e)
        {
            Choices commands = new Choices();
            commands.Add(new string[] { "enter into the my account","one","yeradu" });
            GrammarBuilder gBuilder = new GrammarBuilder();
            gBuilder.Append(commands);
            Grammar grammar = new Grammar(gBuilder);
            recEngine.LoadGrammarAsync(grammar);
            recEngine.SetInputToDefaultAudioDevice();
            recEngine.SpeechRecognized += sre_SpeechRecognized;


            recEngine.RecognizeAsync(RecognizeMode.Multiple);
            // synth.SetOutputToDefaultAudioDevice();
            //synth.SelectVoiceByHints(VoiceGender.Female, VoiceAge.Teen);
            synth.SetOutputToDefaultAudioDevice();
            synth.Rate = -2;
            synth.Speak("Namaste A T M saevegge swaagatha");
            synth.Speak("For English say one");
            synth.Speak("Kannadakagi yeradu yendhu yelli");
        }


        void sre_SpeechRecognized(object sender, SpeechRecognizedEventArgs e)
        {
            synth.SetOutputToDefaultAudioDevice();
            switch (e.Result.Text.ToLower())
            {
                case "enter into the my account":
                    //Form1 f2 = new Form1();
                    //f2.Show();
                    //this.Hide();
                    break;

                case "one":
                    CustAccount f2 = new CustAccount(nn, an);
                    this.Hide();
                    f2.ShowDialog();
                    this.Close();
                    break;
                case "yeradu":
                    CustAccountK f3 = new CustAccountK(nn, an);
                    this.Hide();
                    f3.ShowDialog();
                    this.Close();
                    break;

            }
            //MessageBox.Show("Speech recognized: " + e.Result.Text);
            //if (!stopper)
            //{
            //    textBox1.Text += " ";
            //    textBox1.Text += e.Result.Text;
            //}
            //stopper = false;
        }
    }
}
