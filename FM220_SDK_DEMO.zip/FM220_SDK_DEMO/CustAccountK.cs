﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Speech.Recognition;
using System.Speech.Synthesis;
using System.Text;
using System.Windows.Forms;

namespace FM220_SDK_DEMO
{
    public partial class CustAccountK : Form
    {
        SpeechRecognitionEngine recEngine = new SpeechRecognitionEngine();
        SpeechSynthesizer synth = new SpeechSynthesizer();
        string email = "madhsunil@gmail.com";
        bool isSubject = false, isBody = false, isreciever = false;
        bool stopper = false;
        string eSub = string.Empty;
        string eBod = string.Empty;
        string eRec = string.Empty;
        bool subject = false;
        bool body = false;

        static string nn = "";
        static string an = "";

        String sessionval = "";

      
        public CustAccountK()
        {
            InitializeComponent();
        }

        public CustAccountK(String Aname, String Anum)
        {
            InitializeComponent();
            nn = Aname;
            an = Anum;
            sessionval = Aname;
        }

        private void CustAccount_Load(object sender, EventArgs e)
        {
            Choices commands = new Choices();
            commands.Add(new string[] { "kaatheya baaki mottha","kaatheya  withdraw ","logout", "raghavendra", "praveen", "kaatheya baaki mottha", "raghavendra account", "praveen account", "nooru", "in nooru", "moonnooru", "i nooru", "saavveera", "balance enquiry", "withdrawal", "mini statement", " kaatheya mini statement", "send email", "sunil", "receiver", "this", "is", "a", "test", "subject", "body", "email subject", "email body", "email receiver", "start Recording", "stop Recording", "this is a sample subject", "this is a sample body" });
            GrammarBuilder gBuilder = new GrammarBuilder();
            gBuilder.Append(commands);
            Grammar grammar = new Grammar(gBuilder);
            recEngine.LoadGrammarAsync(grammar);
            recEngine.SetInputToDefaultAudioDevice();
            recEngine.SpeechRecognized += sre_SpeechRecognized;




            recEngine.RecognizeAsync(RecognizeMode.Multiple);
            synth.SetOutputToDefaultAudioDevice();
            synth.Rate = -2;
            synth.Speak("nimma aayakegalu");
            synth.Speak("hanaa vapasaathige   kaatheya  withdraw      hendhu elli");
            synth.Speak("kaatheya mottha thiliyalu kaatheya baaki mottha hendhu elli");
            synth.Speak("nimma kaateyaa ministatement thiliddu kollalu kaatheya ministatement henddhu elli ");
            synth.Rate = -3;
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\Project\Dot Net\Fingerprint web n Standalone\FM220_SDK_DEMO\db\VoiceAtmDb.mdf;Integrated Security=True;Connect Timeout=30");
            con.Open();
            string query = "Select balance from Account where Pname='" + sessionval + "'";
            SqlCommand cmd = new SqlCommand(query, con);
            label4.Text = Convert.ToString(cmd.ExecuteScalar());
            label4.Text += " Rupees";
            con.Close();

        }



        void sre_SpeechRecognized(object sender, SpeechRecognizedEventArgs e)
        {
            synth.SetOutputToDefaultAudioDevice();
            switch (e.Result.Text.ToLower())
            {
                case "kaatheya  withdraw":
                    synth.Speak("mottha heli");
                    break;
                case "nooru":
                    float amt = 100;
                    SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\Project\Dot Net\Fingerprint web n Standalone\FM220_SDK_DEMO\db\VoiceAtmDb.mdf;Integrated Security=True;Connect Timeout=30");
                    con.Open();
                    string query = "Select balance from Account where Pname='" + sessionval + "'";
                    SqlCommand cmd = new SqlCommand(query, con);
                    double amter = Convert.ToDouble(cmd.ExecuteScalar());
                    amter = amter - amt;


                    synth.Speak("nooru rupaiye jame agide");

                    query = "Update Account set balance='" + amter.ToString() + "' where Pname='" + sessionval + "'";
                    cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();

                    query = "insert into Trans values('" + sessionval + "','" + DateTime.Now.ToString("MM-dd-yyyy") + "','Credited','100 rupees')";
                    cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();

                    synth.Speak("Vyavahāra mugidide");

                    con.Close();
                    break;
                case "in nooru":

                    //synth.Speak("200 Rupees will be deducted from the account");
                    amt = 200;
                    con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\Project\Dot Net\Fingerprint web n Standalone\FM220_SDK_DEMO\db\VoiceAtmDb.mdf;Integrated Security=True;Connect Timeout=30");
                    con.Open();
                    query = "Select balance from Account where Pname='"+sessionval+"'";
                    cmd = new SqlCommand(query, con);
                    amter = Convert.ToDouble(cmd.ExecuteScalar());
                    amter = amter - amt;

                    synth.Speak("in nooru rupaiye jame agide");
                    query = "Update Account set balance='" + amter.ToString() + "' where Pname='raghavendra'";
                    cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();


                    query = "insert into Trans values('" + sessionval + "','" + DateTime.Today.ToShortDateString() + "','Credited','200 rupees')";
                    cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();

                    synth.Speak("Vyavahāra mugidide");

                    con.Close();
                    break;
                case "moonnooru":

                    //synth.Speak("200 Rupees will be deducted from the account");
                    amt = 300;
                    con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\Project\Dot Net\Fingerprint web n Standalone\FM220_SDK_DEMO\db\VoiceAtmDb.mdf;Integrated Security=True;Connect Timeout=30");
                    con.Open();
                    query = "Select balance from Account where Pname='" + sessionval + "'";
                    cmd = new SqlCommand(query, con);
                    amter = Convert.ToDouble(cmd.ExecuteScalar());
                    amter = amter - amt;

                    synth.Speak("mun nooru rupaiye jame agide");
                    query = "Update Account set balance='" + amter.ToString() + "' where Pname='raghavendra'";
                    cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();


                    query = "insert into Trans values('" + sessionval + "','" + DateTime.Today.ToShortDateString() + "','Credited','200 rupees')";
                    cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();

                    synth.Speak("Vyavahāra mugidide");

                    con.Close();
                    break;
                case "i nooru":

                    //synth.Speak("200 Rupees will be deducted from the account");
                    amt = 500;
                    con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\Project\Dot Net\Fingerprint web n Standalone\FM220_SDK_DEMO\db\VoiceAtmDb.mdf;Integrated Security=True;Connect Timeout=30");
                    con.Open();
                    query = "Select balance from Account where Pname='" + sessionval + "'";
                    cmd = new SqlCommand(query, con);
                    amter = Convert.ToDouble(cmd.ExecuteScalar());
                    amter = amter - amt;

                    synth.Speak("i nooru rupaiye jame agide");
                    query = "Update Account set balance='" + amter.ToString() + "' where Pname='raghavendra'";
                    cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();


                    query = "insert into Trans values('" + sessionval + "','" + DateTime.Today.ToShortDateString() + "','Credited','200 rupees')";
                    cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();

                    synth.Speak("Vyavahāra mugidide");

                    con.Close();
                    break;
                case "saavveera":

                    //synth.Speak("200 Rupees will be deducted from the account");
                    amt = 1000;
                    con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\Project\Dot Net\Fingerprint web n Standalone\FM220_SDK_DEMO\db\VoiceAtmDb.mdf;Integrated Security=True;Connect Timeout=30");
                    con.Open();
                    query = "Select balance from Account where Pname='" + sessionval + "'";
                    cmd = new SqlCommand(query, con);
                    amter = Convert.ToDouble(cmd.ExecuteScalar());
                    amter = amter - amt;

                    synth.Speak("savira rupaiye jame agide");
                    query = "Update Account set balance='" + amter.ToString() + "' where Pname='raghavendra'";
                    cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();


                    query = "insert into Trans values('" + sessionval + "','" + DateTime.Today.ToShortDateString() + "','Credited','200 rupees')";
                    cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();

                    synth.Speak("Vyavahāra mugidide");

                    con.Close();
                    break;
                case "kaatheya ministatement":

                    synth.Speak( sessionval + ", kaatheya mini statement");
                    
                    //synth.Speak("10-10-2019 credited 1000 rupees");
                    //synth.Speak("10-10-2019 debited 5800 rupees");
                    con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\Project\Dot Net\Fingerprint web n Standalone\FM220_SDK_DEMO\db\VoiceAtmDb.mdf;Integrated Security=True;Connect Timeout=30");
                    con.Open();
                    query = "Select top 5 * from Trans where AccHold='" + sessionval + "'";
                    cmd = new SqlCommand(query, con);
                    SqlDataReader dr = cmd.ExecuteReader();
                    string str = "";
                    if (dr.HasRows)
                    {
                        while (dr.Read())
                        {
                            str = str + dr.GetValue(1).ToString() + " Jaame " + dr.GetValue(3).ToString() + "\n";
                        }
                    }
                    dr.Close();

                    synth.Speak(str);
                    label5.Text = str;
                    //query = "Update Account set balance='" + amter.ToString() + "' where Pname='raghavendra'";
                    //cmd = new SqlCommand(query, con);
                    //cmd.ExecuteNonQuery();


                    con.Close();
                    break;


                case "withdrawal":
                    synth.Speak("Please specify the name");
                    break;
                case "logout":
                    synth.Speak("Dhanyavadagalu namma seveyannu upayogisidakke");
                    synth.Speak("shubadina");
                    Home f2 = new Home();
                    this.Hide();
                    f2.ShowDialog();
                    this.Close();
                    break;

                case "balance enquiry":
                    synth.Speak("Please specify the name");
                    //System.Diagnostics.Process.Start(@"C:\Users\admin\AppData\Local\Google\Chrome\Application\chrome.exe");

                    break;
                case "khatheya baaki mottha":
                    con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\Project\Dot Net\Fingerprint web n Standalone\FM220_SDK_DEMO\db\VoiceAtmDb.mdf;Integrated Security=True;Connect Timeout=30");
                    con.Open();
                    query = "Select balance from Account where Pname='" + sessionval + "'";
                    cmd = new SqlCommand(query, con);
                    label4.Text = Convert.ToString(cmd.ExecuteScalar());
                    label4.Text += " Rupees";
                    con.Close();
                    synth.Speak(""+sessionval+ ", kaatheya baaki mottha");

                    synth.Speak(label4.Text);
                    break;
                //default:
                //    synth.Speak("Sorry. I am not able to recognize your command");
                //    break;

                    //case "receiver":
                    //    textBox1.Text += e.Result.Text;

                    //    textBox1.Text += "\n email id:"+email;
                    //    synth.Speak("Receiver captured");
                    //    //System.Diagnostics.Process.Start(@"C:\Users\admin\AppData\Local\Google\Chrome\Application\chrome.exe");
                    //    break;
                    //case "sunil":
                    //    textBox1.Text += e.Result.Text;
                    //    synth.Speak("Receiver captured");

                    //    textBox1.Text += "\n email id:" + email;
                    //    //System.Diagnostics.Process.Start(@"C:\Users\admin\AppData\Local\Google\Chrome\Application\chrome.exe");
                    //    break;


            }
            //MessageBox.Show("Speech recognized: " + e.Result.Text);
            //if (!stopper)
            //{
            //    textBox1.Text += " ";
            //    textBox1.Text += e.Result.Text;
            //}
            //stopper = false;
        }
    }
}
