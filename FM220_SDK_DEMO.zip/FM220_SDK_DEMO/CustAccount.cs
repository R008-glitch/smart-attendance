﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Speech.Recognition;
using System.Speech.Synthesis;
using System.Text;
using System.Windows.Forms;

namespace FM220_SDK_DEMO
{
    public partial class CustAccount : Form
    {
        SpeechRecognitionEngine recEngine = new SpeechRecognitionEngine();
        SpeechSynthesizer synth = new SpeechSynthesizer();
        string email = "madhsunil@gmail.com";
        bool isSubject = false, isBody = false, isreciever = false;
        bool stopper = false;
        string eSub = string.Empty;
        string eBod = string.Empty;
        string eRec = string.Empty;
        bool subject = false;
        bool body = false;

        static string nn = "";
        static string an = "";

        String sessionval = "ramya";

      
        public CustAccount()
        {
            InitializeComponent();
        }

        public CustAccount(String Aname, String Anum)
        {
            InitializeComponent();
            nn = Aname;
            an = Anum;
            sessionval = "ramya";//Aname;
        }

        private void CustAccount_Load(object sender, EventArgs e)
        {
            Choices commands = new Choices();
            commands.Add(new string[] { "logout", "raghavendra","maximum amount", "prave0en", "balance of my account", "withdrawal of my account", "raghavendra account", "praveen account", "hundred", "two hundred", "three hundred", "five hundred", "thousand", "balance enquiry", "withdrawal", "mini statement", "mini statement of my account", "send email", "sunil", "receiver", "this", "is", "a", "test", "subject", "body", "email subject", "email body", "email receiver", "start Recording", "stop Recording", "this is a sample subject", "this is a sample body" });
            GrammarBuilder gBuilder = new GrammarBuilder();
            gBuilder.Append(commands);
            Grammar grammar = new Grammar(gBuilder);
            recEngine.LoadGrammarAsync(grammar);
            recEngine.SetInputToDefaultAudioDevice();
            recEngine.SpeechRecognized += sre_SpeechRecognized;




            recEngine.RecognizeAsync(RecognizeMode.Multiple);
            synth.SetOutputToDefaultAudioDevice();
            synth.Speak("Please input your command");
            synth.Speak("For withdrawal say withdrawal of my account");
            synth.Speak("For balance enquiry say balance  of my account");
            synth.Speak("For mini statement say mini statement of my account");
            synth.Rate = -3;
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\Project\Dot Net\Fingerprint web n Standalone\FM220_SDK_DEMO\db\VoiceAtmDb.mdf;Integrated Security=True;Connect Timeout=30");
            con.Open();
            string query = "Select balance from Account where Pname='" + sessionval + "'";
            SqlCommand cmd = new SqlCommand(query, con);
            label4.Text = Convert.ToString(cmd.ExecuteScalar());
            label4.Text += " Rupees";
            con.Close();

        }



        void sre_SpeechRecognized(object sender, SpeechRecognizedEventArgs e)
        {
            synth.SetOutputToDefaultAudioDevice();
            switch (e.Result.Text.ToLower())
            {
                case "withdrawal of my account":
                    synth.Speak("Please specify the amount");
                    break;
                case "praveen account":
                    synth.Speak("Please specify the amount");
                    break;
                case "hundred":
                    float amt = 100;
                    SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\Project\Dot Net\Fingerprint web n Standalone\FM220_SDK_DEMO\db\VoiceAtmDb.mdf;Integrated Security=True;Connect Timeout=30");
                    con.Open();
                    string query = "Select balance from Account where Pname='" + sessionval + "'";
                    SqlCommand cmd = new SqlCommand(query, con);
                    double amter = Convert.ToDouble(cmd.ExecuteScalar());
                    amter = amter - amt;


                    synth.Speak("100 Rupees will be deducted from the account");

                    query = "Update Account set balance='" + amter.ToString() + "' where Pname='" + sessionval + "'";
                    cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();

                    query = "insert into Trans values('" + sessionval + "','" + DateTime.Now.ToString("MM-dd-yyyy") + "','Credited','100 rupees')";
                    cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();

                    synth.Speak("Transaction completed");

                    con.Close();
                    break;
                case "two hundred":

                    synth.Speak("200 Rupees will be deducted from the account");
                    amt = 200;
                    con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\Project\Dot Net\Fingerprint web n Standalone\FM220_SDK_DEMO\db\VoiceAtmDb.mdf;Integrated Security=True;Connect Timeout=30");
                    con.Open();
                    query = "Select balance from Account where Pname='"+sessionval+"'";
                    cmd = new SqlCommand(query, con);
                    amter = Convert.ToDouble(cmd.ExecuteScalar());
                    amter = amter - amt;

                    query = "Update Account set balance='" + amter.ToString() + "' where Pname='raghavendra'";
                    cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();


                    query = "insert into Trans values('" + sessionval + "','" + DateTime.Today.ToShortDateString() + "','Credited','200 rupees')";
                    cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();

                    synth.Speak("Transaction completed");

                    con.Close();
                    break;
                    case "three hundred":

                    synth.Speak("300 Rupees will be deducted from the account");
                    amt = 300;
                    con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\Project\Dot Net\Fingerprint web n Standalone\FM220_SDK_DEMO\db\VoiceAtmDb.mdf;Integrated Security=True;Connect Timeout=30");
                    con.Open();
                    query = "Select balance from Account where Pname='" + sessionval + "'";
                    cmd = new SqlCommand(query, con);
                    amter = Convert.ToDouble(cmd.ExecuteScalar());
                    amter = amter - amt;

                    query = "Update Account set balance='" + amter.ToString() + "' where Pname='raghavendra'";
                    cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();


                    query = "insert into Trans values('" + sessionval + "','" + DateTime.Today.ToShortDateString() + "','Credited','200 rupees')";
                    cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();

                    synth.Speak("Transaction completed");

                    con.Close();
                    break;
                case "ive hundred":

                    synth.Speak("500 Rupees will be deducted from the account");
                    amt = 500;
                    con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\Project\Dot Net\Fingerprint web n Standalone\FM220_SDK_DEMO\db\VoiceAtmDb.mdf;Integrated Security=True;Connect Timeout=30");
                    con.Open();
                    query = "Select balance from Account where Pname='" + sessionval + "'";
                    cmd = new SqlCommand(query, con);
                    amter = Convert.ToDouble(cmd.ExecuteScalar());
                    amter = amter - amt;

                    query = "Update Account set balance='" + amter.ToString() + "' where Pname='raghavendra'";
                    cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();


                    query = "insert into Trans values('" + sessionval + "','" + DateTime.Today.ToShortDateString() + "','Credited','200 rupees')";
                    cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();

                    synth.Speak("Transaction completed");

                    con.Close();
                    break;
                case "thousand":

                    synth.Speak("1000 Rupees will be deducted from the account");
                    amt = 1000;
                    con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\Project\Dot Net\Fingerprint web n Standalone\FM220_SDK_DEMO\db\VoiceAtmDb.mdf;Integrated Security=True;Connect Timeout=30");
                    con.Open();
                    query = "Select balance from Account where Pname='" + sessionval + "'";
                    cmd = new SqlCommand(query, con);
                    amter = Convert.ToDouble(cmd.ExecuteScalar());
                    amter = amter - amt;

                    query = "Update Account set balance='" + amter.ToString() + "' where Pname='raghavendra'";
                    cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();


                    query = "insert into Trans values('" + sessionval + "','" + DateTime.Today.ToShortDateString() + "','Credited','200 rupees')";
                    cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();

                    synth.Speak("Transaction completed");

                    con.Close();
                    break;
                case "mini statement of my account":

                    synth.Speak("Hi " + sessionval + ", mini statement of your account");
                    
                    //synth.Speak("10-10-2019 credited 1000 rupees");
                    //synth.Speak("10-10-2019 debited 5800 rupees");
                    con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\Project\Dot Net\Fingerprint web n Standalone\FM220_SDK_DEMO\db\VoiceAtmDb.mdf;Integrated Security=True;Connect Timeout=30");
                    con.Open();
                    query = "Select top 5 * from Trans where AccHold='" + sessionval + "'";
                    cmd = new SqlCommand(query, con);
                    SqlDataReader dr = cmd.ExecuteReader();
                    string str = "";
                    if (dr.HasRows)
                    {
                        while (dr.Read())
                        {
                            str = str + dr.GetValue(1).ToString() + " " + dr.GetValue(2).ToString() + " " + dr.GetValue(3).ToString() + "\n";
                        }
                    }
                    dr.Close();

                    synth.Speak(str);
                    label5.Text = str;
                    //query = "Update Account set balance='" + amter.ToString() + "' where Pname='raghavendra'";
                    //cmd = new SqlCommand(query, con);
                    //cmd.ExecuteNonQuery();


                    con.Close();
                    break;


                case "withdrawal":
                    synth.Speak("Please specify the name");
                    break;
                case "logout":
                    synth.Speak("Thank you for using VOICE Based A T M services.");
                    synth.Speak("Bye Bye. Have a nice day");
                    Home f2 = new Home();
                    this.Hide();
                    f2.ShowDialog();
                    this.Close();
                    break;

                case "balance enquiry":
                    synth.Speak("Please specify the name");
                    //System.Diagnostics.Process.Start(@"C:\Users\admin\AppData\Local\Google\Chrome\Application\chrome.exe");

                    break;
                case "balance of my account":
                    con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\Project\Dot Net\Fingerprint web n Standalone\FM220_SDK_DEMO\db\VoiceAtmDb.mdf;Integrated Security=True;Connect Timeout=30");
                    con.Open();
                    query = "Select balance from Account where Pname='" + sessionval + "'";
                    cmd = new SqlCommand(query, con);
                    label4.Text = Convert.ToString(cmd.ExecuteScalar());
                    label4.Text += " Rupees";
                    con.Close();
                    synth.Speak("Hi "+sessionval+", Balance of your account");

                    synth.Speak(label4.Text);
                    break;
                case "maximum amount":
                    float aamt = 1400;
                    SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\Project\Dot Net\Fingerprint web n Standalone\FM220_SDK_DEMO\db\VoiceAtmDb.mdf;Integrated Security=True;Connect Timeout=30");
                    conn.Open();
                    string queryy = "Select balance from Account where Pname='" + sessionval + "'";
                    SqlCommand cmmd = new SqlCommand(queryy, conn);
                    double aamter = Convert.ToDouble(cmmd.ExecuteScalar());
                    aamter = aamter - aamt;


                    synth.Speak("max amount will be deducted from the account");

                    query = "Update Account set balance='" + aamter.ToString() + "' where Pname='" + sessionval + "'";
                    cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();

                    query = "insert into Trans values('" + sessionval + "','" + DateTime.Now.ToString("MM-dd-yyyy") + "','Credited','100 rupees')";
                    cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();

                    synth.Speak("Transaction completed");

                    conn.Close();
                    break;

                    //default:
                    //    synth.Speak("Sorry. I am not able to recognize your command");
                    //    break;

                    //case "receiver":
                    //    textBox1.Text += e.Result.Text;

                    //    textBox1.Text += "\n email id:"+email;
                    //    synth.Speak("Receiver captured");
                    //    //System.Diagnostics.Process.Start(@"C:\Users\admin\AppData\Local\Google\Chrome\Application\chrome.exe");
                    //    break;
                    //case "sunil":
                    //    textBox1.Text += e.Result.Text;
                    //    synth.Speak("Receiver captured");

                    //    textBox1.Text += "\n email id:" + email;
                    //    //System.Diagnostics.Process.Start(@"C:\Users\admin\AppData\Local\Google\Chrome\Application\chrome.exe");
                    //    break;


            }
            //MessageBox.Show("Speech recognized: " + e.Result.Text);
            //if (!stopper)
            //{
            //    textBox1.Text += " ";
            //    textBox1.Text += e.Result.Text;
            //}
            //stopper = false;
        }
    }
}
