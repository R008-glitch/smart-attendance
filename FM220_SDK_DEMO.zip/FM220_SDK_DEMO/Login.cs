﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Speech.Recognition;
using System.Speech.Synthesis;
using System.Text;
using System.Windows.Forms;

namespace FM220_SDK_DEMO
{
    public partial class Login : Form
    {
        SpeechRecognitionEngine recEngine = new SpeechRecognitionEngine();
        int counter = 0;

        SpeechSynthesizer synth = new SpeechSynthesizer();
        public Login()
        {
            InitializeComponent();
        }

        //private void Login_Load(object sender, EventArgs e)
        //{
        //    Choices commands = new Choices();
        //    commands.Add(new string[] { "anjali", "divya", "Vinay", "demo", "email send", "sunil", "receiver", "this", "is", "a", "test", "subject", "body" });
        //    GrammarBuilder gBuilder = new GrammarBuilder();
        //    gBuilder.Append(commands);
        //    Grammar grammar = new Grammar(gBuilder);
        //    recEngine.LoadGrammarAsync(grammar);
        //    recEngine.SetInputToDefaultAudioDevice();
        //    recEngine.SpeechRecognized += sre_SpeechRecognized;
        //}

        void sre_SpeechRecognized(object sender, SpeechRecognizedEventArgs e)
        {
            synth.SetOutputToDefaultAudioDevice();
            switch (e.Result.Text.ToLower())
            {
                case "ramya":
                    synth.Speak("User recognized. Welcome back ramya.");
                    synth.Speak("Please specify your password");

                    //System.Diagnostics.Process.Start(@"C:\Users\admin\AppData\Local\Google\Chrome\Application\chrome.exe");
                    break;
                case "admin":
                    if (counter == 0)
                    {
                        synth.Speak("Hello admin");
                        synth.Speak("Please specify your password");
                        counter++;
                    }
                    else
                    {
                        if(counter==1)
                        {
                            synth.Speak("Redirecting to admin homwpage");
                            recEngine.RecognizeAsyncStop();
                            //AdminHome fx = new AdminHome();
                           // fx.Show();
                            this.Hide();
                        }
                    }

                    //System.Diagnostics.Process.Start(@"C:\Users\admin\AppData\Local\Google\Chrome\Application\chrome.exe");
                    break;
                case "demo":
                    //textBox1.Text += e.Result.Text;
                    synth.Speak("You are authenticated");
                    synth.Speak("You will be redirected to atm application");
                    recEngine.RecognizeAsyncStop();
                    CustomerHome f = new CustomerHome();
                    f.Show();
                    this.Hide();
                    //System.Diagnostics.Process.Start(@"C:\Users\admin\AppData\Local\Google\Chrome\Application\chrome.exe");
                    break;
                //case "Smitha":
                //    synth.Speak("User recognized. Welcome back Smitha.");
                //    synth.Speak("Please specify your password");

                //    //System.Diagnostics.Process.Start(@"C:\Users\admin\AppData\Local\Google\Chrome\Application\chrome.exe");
                //    break;
                case "abcd":
                    //textBox1.Text += e.Result.Text;
                    synth.Speak("You are authenticated");
                    synth.Speak("You will be redirected to email application");
                    Form1 f1 = new Form1();
                    f1.Show();
                    this.Hide();
                    //System.Diagnostics.Process.Start(@"C:\Users\admin\AppData\Local\Google\Chrome\Application\chrome.exe");
                    break;
                //case "divya":
                //    synth.Speak("User recognized. Welcome back divya.");
                //    synth.Speak("Please specify your password");

                //    //System.Diagnostics.Process.Start(@"C:\Users\admin\AppData\Local\Google\Chrome\Application\chrome.exe");
                //    break;
                case "passy":
                    //textBox1.Text += e.Result.Text;
                    synth.Speak("You are authenticated");
                    synth.Speak("You will be redirected to atm application");
                    recEngine.RecognizeAsyncStop();
                    Form1 f2 = new Form1();
                    f2.Show();
                    this.Hide();
                    //System.Diagnostics.Process.Start(@"C:\Users\admin\AppData\Local\Google\Chrome\Application\chrome.exe");
                    break;
            }
            //MessageBox.Show("Speech recognized: " + e.Result.Text);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            synth.SetOutputToDefaultAudioDevice();

            recEngine.RecognizeAsync(RecognizeMode.Multiple);

            synth.Speak("Voice Based application loaded");
            synth.Speak("Please specify your username");
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Login_Load(object sender, EventArgs e)
        {

            Choices commands = new Choices();
            commands.Add(new string[] {"admin","ramya", "passy", "anjali", "divya", "Vinay", "demo", "email send", "sunil", "receiver", "this", "is", "a", "test", "subject", "body" });
            GrammarBuilder gBuilder = new GrammarBuilder();
            gBuilder.Append(commands);
            Grammar grammar = new Grammar(gBuilder);
            recEngine.LoadGrammarAsync(grammar);
            recEngine.SetInputToDefaultAudioDevice();
            recEngine.SpeechRecognized += sre_SpeechRecognized;

          //  Connection connector = new Connection();
          //  if (connector.isChecker())
            {

                synth.SetOutputToDefaultAudioDevice();

                recEngine.RecognizeAsync(RecognizeMode.Multiple);

                synth.Speak("Voice Based A T M application loaded");
                synth.Speak("Please specify your username");
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}